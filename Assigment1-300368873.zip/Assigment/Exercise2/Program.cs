﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("      0000      0000    0      0 00000000 0        000000  00000000  ");
            Console.WriteLine("      0   0    0    0   0      0 0        0       0      0 0         ");
            Console.WriteLine("      0    0   0    0   0      0 0        0       0      0 0         ");
            Console.WriteLine("      0     0 0      0  0      0 00000000 0        000000  00000000  ");
            Console.WriteLine("      0    0   0    0   0      0 0      0 0       0      0        0  ");
            Console.WriteLine("      0   0    0    0    0    0   0     0 0       0      0        0  ");
            Console.WriteLine("      0000      0000      0000     00000  0000000 0      0 00000000  ");

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("By Javier Navarro 300368873 Douglas College");
            Console.WriteLine("Hello World");
            Console.ReadKey();
        }
    }
}
