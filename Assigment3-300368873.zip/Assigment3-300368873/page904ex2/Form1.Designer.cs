﻿namespace page904ex2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.RdBox = new System.Windows.Forms.ListBox();
            this.OrganizeBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Avglabel = new System.Windows.Forms.Label();
            this.Maxlabel = new System.Windows.Forms.Label();
            this.Minlabel = new System.Windows.Forms.Label();
            this.FiletextBox = new System.Windows.Forms.TextBox();
            this.Actionbutton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Proccesslabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // RdBox
            // 
            this.RdBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RdBox.FormattingEnabled = true;
            this.RdBox.ItemHeight = 18;
            this.RdBox.Location = new System.Drawing.Point(13, 23);
            this.RdBox.Name = "RdBox";
            this.RdBox.Size = new System.Drawing.Size(360, 364);
            this.RdBox.TabIndex = 0;
            // 
            // OrganizeBox
            // 
            this.OrganizeBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrganizeBox.FormattingEnabled = true;
            this.OrganizeBox.ItemHeight = 18;
            this.OrganizeBox.Location = new System.Drawing.Point(411, 23);
            this.OrganizeBox.Name = "OrganizeBox";
            this.OrganizeBox.Size = new System.Drawing.Size(360, 364);
            this.OrganizeBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Input File";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(408, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Organize File";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(777, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Avg:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(777, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Max:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(777, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Min:";
            // 
            // Avglabel
            // 
            this.Avglabel.AutoSize = true;
            this.Avglabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Avglabel.Location = new System.Drawing.Point(846, 20);
            this.Avglabel.Name = "Avglabel";
            this.Avglabel.Size = new System.Drawing.Size(31, 16);
            this.Avglabel.TabIndex = 7;
            this.Avglabel.Text = "Avg";
            // 
            // Maxlabel
            // 
            this.Maxlabel.AutoSize = true;
            this.Maxlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Maxlabel.Location = new System.Drawing.Point(846, 57);
            this.Maxlabel.Name = "Maxlabel";
            this.Maxlabel.Size = new System.Drawing.Size(32, 16);
            this.Maxlabel.TabIndex = 8;
            this.Maxlabel.Text = "Max";
            // 
            // Minlabel
            // 
            this.Minlabel.AutoSize = true;
            this.Minlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Minlabel.Location = new System.Drawing.Point(846, 94);
            this.Minlabel.Name = "Minlabel";
            this.Minlabel.Size = new System.Drawing.Size(28, 16);
            this.Minlabel.TabIndex = 9;
            this.Minlabel.Text = "Min";
            // 
            // FiletextBox
            // 
            this.FiletextBox.Location = new System.Drawing.Point(141, 393);
            this.FiletextBox.Name = "FiletextBox";
            this.FiletextBox.Size = new System.Drawing.Size(630, 20);
            this.FiletextBox.TabIndex = 10;
            // 
            // Actionbutton
            // 
            this.Actionbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Actionbutton.Location = new System.Drawing.Point(803, 179);
            this.Actionbutton.Name = "Actionbutton";
            this.Actionbutton.Size = new System.Drawing.Size(75, 32);
            this.Actionbutton.TabIndex = 11;
            this.Actionbutton.Text = "Read";
            this.Actionbutton.UseVisualStyleBackColor = true;
            this.Actionbutton.Click += new System.EventHandler(this.readfile);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(70, 400);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Avg:";
            // 
            // Proccesslabel
            // 
            this.Proccesslabel.AutoSize = true;
            this.Proccesslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Proccesslabel.Location = new System.Drawing.Point(846, 131);
            this.Proccesslabel.Name = "Proccesslabel";
            this.Proccesslabel.Size = new System.Drawing.Size(64, 16);
            this.Proccesslabel.TabIndex = 14;
            this.Proccesslabel.Text = "Proccess";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(777, 134);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Proccessed:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 450);
            this.Controls.Add(this.Proccesslabel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Actionbutton);
            this.Controls.Add(this.FiletextBox);
            this.Controls.Add(this.Minlabel);
            this.Controls.Add(this.Maxlabel);
            this.Controls.Add(this.Avglabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OrganizeBox);
            this.Controls.Add(this.RdBox);
            this.Name = "Form1";
            this.Text = "Rdfile";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox RdBox;
        private System.Windows.Forms.ListBox OrganizeBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Avglabel;
        private System.Windows.Forms.Label Maxlabel;
        private System.Windows.Forms.Label Minlabel;
        private System.Windows.Forms.TextBox FiletextBox;
        private System.Windows.Forms.Button Actionbutton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Proccesslabel;
        private System.Windows.Forms.Label label8;
    }
}

