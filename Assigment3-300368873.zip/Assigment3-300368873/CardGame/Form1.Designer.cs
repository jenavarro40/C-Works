﻿namespace CardGame
{
    partial class GameForm
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Compbutton1 = new System.Windows.Forms.Button();
            this.Compbutton2 = new System.Windows.Forms.Button();
            this.Compbutton3 = new System.Windows.Forms.Button();
            this.Compbutton4 = new System.Windows.Forms.Button();
            this.Playerbutton4 = new System.Windows.Forms.Button();
            this.Playerbutton3 = new System.Windows.Forms.Button();
            this.Playerbutton2 = new System.Windows.Forms.Button();
            this.Playerbutton1 = new System.Windows.Forms.Button();
            this.Newbutton = new System.Windows.Forms.Button();
            this.Donebutton = new System.Windows.Forms.Button();
            this.Betbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Complabel1 = new System.Windows.Forms.Label();
            this.Complabel2 = new System.Windows.Forms.Label();
            this.Complabel3 = new System.Windows.Forms.Label();
            this.Complabel4 = new System.Windows.Forms.Label();
            this.Playerlabel1 = new System.Windows.Forms.Label();
            this.Playerlabel2 = new System.Windows.Forms.Label();
            this.Playerlabel3 = new System.Windows.Forms.Label();
            this.Playerlabel4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Compbutton1
            // 
            this.Compbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Compbutton1.Location = new System.Drawing.Point(12, 71);
            this.Compbutton1.Name = "Compbutton1";
            this.Compbutton1.Size = new System.Drawing.Size(65, 65);
            this.Compbutton1.TabIndex = 0;
            this.Compbutton1.Text = " ";
            this.Compbutton1.UseVisualStyleBackColor = true;
            // 
            // Compbutton2
            // 
            this.Compbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Compbutton2.Location = new System.Drawing.Point(142, 71);
            this.Compbutton2.Name = "Compbutton2";
            this.Compbutton2.Size = new System.Drawing.Size(65, 65);
            this.Compbutton2.TabIndex = 1;
            this.Compbutton2.Text = " ";
            this.Compbutton2.UseVisualStyleBackColor = true;
            // 
            // Compbutton3
            // 
            this.Compbutton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Compbutton3.Location = new System.Drawing.Point(272, 71);
            this.Compbutton3.Name = "Compbutton3";
            this.Compbutton3.Size = new System.Drawing.Size(65, 65);
            this.Compbutton3.TabIndex = 2;
            this.Compbutton3.Text = " ";
            this.Compbutton3.UseVisualStyleBackColor = true;
            // 
            // Compbutton4
            // 
            this.Compbutton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Compbutton4.Location = new System.Drawing.Point(402, 71);
            this.Compbutton4.Name = "Compbutton4";
            this.Compbutton4.Size = new System.Drawing.Size(65, 65);
            this.Compbutton4.TabIndex = 3;
            this.Compbutton4.Text = " ";
            this.Compbutton4.UseVisualStyleBackColor = true;
            // 
            // Playerbutton4
            // 
            this.Playerbutton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Playerbutton4.Location = new System.Drawing.Point(402, 217);
            this.Playerbutton4.Name = "Playerbutton4";
            this.Playerbutton4.Size = new System.Drawing.Size(65, 65);
            this.Playerbutton4.TabIndex = 7;
            this.Playerbutton4.Text = " ";
            this.Playerbutton4.UseVisualStyleBackColor = true;
            // 
            // Playerbutton3
            // 
            this.Playerbutton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Playerbutton3.Location = new System.Drawing.Point(272, 217);
            this.Playerbutton3.Name = "Playerbutton3";
            this.Playerbutton3.Size = new System.Drawing.Size(65, 65);
            this.Playerbutton3.TabIndex = 6;
            this.Playerbutton3.Text = " ";
            this.Playerbutton3.UseVisualStyleBackColor = true;
            // 
            // Playerbutton2
            // 
            this.Playerbutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Playerbutton2.Location = new System.Drawing.Point(142, 217);
            this.Playerbutton2.Name = "Playerbutton2";
            this.Playerbutton2.Size = new System.Drawing.Size(65, 65);
            this.Playerbutton2.TabIndex = 5;
            this.Playerbutton2.Text = " ";
            this.Playerbutton2.UseVisualStyleBackColor = true;
            // 
            // Playerbutton1
            // 
            this.Playerbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Playerbutton1.Location = new System.Drawing.Point(12, 217);
            this.Playerbutton1.Name = "Playerbutton1";
            this.Playerbutton1.Size = new System.Drawing.Size(65, 65);
            this.Playerbutton1.TabIndex = 4;
            this.Playerbutton1.Text = " ";
            this.Playerbutton1.UseVisualStyleBackColor = true;
            // 
            // Newbutton
            // 
            this.Newbutton.Location = new System.Drawing.Point(157, 396);
            this.Newbutton.Name = "Newbutton";
            this.Newbutton.Size = new System.Drawing.Size(142, 23);
            this.Newbutton.TabIndex = 8;
            this.Newbutton.Text = "New Game";
            this.Newbutton.UseVisualStyleBackColor = true;
            this.Newbutton.Click += new System.EventHandler(this.Newbutton_Click);
            // 
            // Donebutton
            // 
            this.Donebutton.Location = new System.Drawing.Point(324, 320);
            this.Donebutton.Name = "Donebutton";
            this.Donebutton.Size = new System.Drawing.Size(75, 37);
            this.Donebutton.TabIndex = 9;
            this.Donebutton.Text = "Done";
            this.Donebutton.UseVisualStyleBackColor = true;
            this.Donebutton.Click += new System.EventHandler(this.Donebutton_Click);
            // 
            // Betbutton
            // 
            this.Betbutton.Location = new System.Drawing.Point(64, 320);
            this.Betbutton.Name = "Betbutton";
            this.Betbutton.Size = new System.Drawing.Size(75, 37);
            this.Betbutton.TabIndex = 10;
            this.Betbutton.Text = "Bet";
            this.Betbutton.UseVisualStyleBackColor = true;
            this.Betbutton.Click += new System.EventHandler(this.Betbutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Computer´s Cards";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Player´s Cards";
            // 
            // Complabel1
            // 
            this.Complabel1.AutoSize = true;
            this.Complabel1.Location = new System.Drawing.Point(13, 139);
            this.Complabel1.Name = "Complabel1";
            this.Complabel1.Size = new System.Drawing.Size(0, 13);
            this.Complabel1.TabIndex = 13;
            // 
            // Complabel2
            // 
            this.Complabel2.AutoSize = true;
            this.Complabel2.Location = new System.Drawing.Point(139, 139);
            this.Complabel2.Name = "Complabel2";
            this.Complabel2.Size = new System.Drawing.Size(10, 13);
            this.Complabel2.TabIndex = 14;
            this.Complabel2.Text = " ";
            // 
            // Complabel3
            // 
            this.Complabel3.AutoSize = true;
            this.Complabel3.Location = new System.Drawing.Point(269, 139);
            this.Complabel3.Name = "Complabel3";
            this.Complabel3.Size = new System.Drawing.Size(10, 13);
            this.Complabel3.TabIndex = 15;
            this.Complabel3.Text = " ";
            // 
            // Complabel4
            // 
            this.Complabel4.AutoSize = true;
            this.Complabel4.Location = new System.Drawing.Point(399, 139);
            this.Complabel4.Name = "Complabel4";
            this.Complabel4.Size = new System.Drawing.Size(0, 13);
            this.Complabel4.TabIndex = 16;
            // 
            // Playerlabel1
            // 
            this.Playerlabel1.AutoSize = true;
            this.Playerlabel1.Location = new System.Drawing.Point(9, 294);
            this.Playerlabel1.Name = "Playerlabel1";
            this.Playerlabel1.Size = new System.Drawing.Size(0, 13);
            this.Playerlabel1.TabIndex = 17;
            // 
            // Playerlabel2
            // 
            this.Playerlabel2.AutoSize = true;
            this.Playerlabel2.Location = new System.Drawing.Point(139, 294);
            this.Playerlabel2.Name = "Playerlabel2";
            this.Playerlabel2.Size = new System.Drawing.Size(0, 13);
            this.Playerlabel2.TabIndex = 18;
            // 
            // Playerlabel3
            // 
            this.Playerlabel3.AutoSize = true;
            this.Playerlabel3.Location = new System.Drawing.Point(269, 294);
            this.Playerlabel3.Name = "Playerlabel3";
            this.Playerlabel3.Size = new System.Drawing.Size(0, 13);
            this.Playerlabel3.TabIndex = 19;
            // 
            // Playerlabel4
            // 
            this.Playerlabel4.AutoSize = true;
            this.Playerlabel4.Location = new System.Drawing.Point(399, 294);
            this.Playerlabel4.Name = "Playerlabel4";
            this.Playerlabel4.Size = new System.Drawing.Size(0, 13);
            this.Playerlabel4.TabIndex = 20;
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 450);
            this.Controls.Add(this.Playerlabel4);
            this.Controls.Add(this.Playerlabel3);
            this.Controls.Add(this.Playerlabel2);
            this.Controls.Add(this.Playerlabel1);
            this.Controls.Add(this.Complabel4);
            this.Controls.Add(this.Complabel3);
            this.Controls.Add(this.Complabel2);
            this.Controls.Add(this.Complabel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Betbutton);
            this.Controls.Add(this.Donebutton);
            this.Controls.Add(this.Newbutton);
            this.Controls.Add(this.Playerbutton4);
            this.Controls.Add(this.Playerbutton3);
            this.Controls.Add(this.Playerbutton2);
            this.Controls.Add(this.Playerbutton1);
            this.Controls.Add(this.Compbutton4);
            this.Controls.Add(this.Compbutton3);
            this.Controls.Add(this.Compbutton2);
            this.Controls.Add(this.Compbutton1);
            this.Name = "GameForm";
            this.Text = "Card Game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Compbutton1;
        private System.Windows.Forms.Button Compbutton2;
        private System.Windows.Forms.Button Compbutton3;
        private System.Windows.Forms.Button Compbutton4;
        private System.Windows.Forms.Button Playerbutton4;
        private System.Windows.Forms.Button Playerbutton3;
        private System.Windows.Forms.Button Playerbutton2;
        private System.Windows.Forms.Button Playerbutton1;
        private System.Windows.Forms.Button Newbutton;
        private System.Windows.Forms.Button Donebutton;
        private System.Windows.Forms.Button Betbutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Complabel1;
        private System.Windows.Forms.Label Complabel2;
        private System.Windows.Forms.Label Complabel3;
        private System.Windows.Forms.Label Complabel4;
        private System.Windows.Forms.Label Playerlabel1;
        private System.Windows.Forms.Label Playerlabel2;
        private System.Windows.Forms.Label Playerlabel3;
        private System.Windows.Forms.Label Playerlabel4;
    }
}

